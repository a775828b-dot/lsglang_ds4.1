# Copyright (c) 2025 by FlashInfer team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

try:
    import quack  # noqa: F401
except ImportError as e:
    raise ImportError(
        "The vsa_sm100_blk128 backend requires the `quack-kernels` package.\n"
        "Install it from PyPI (--no-deps: quack-kernels pins an older "
        "nvidia-cutlass-dsl than flashinfer requires):\n"
        "    pip install --no-deps quack-kernels==0.6.4"
    ) from e
